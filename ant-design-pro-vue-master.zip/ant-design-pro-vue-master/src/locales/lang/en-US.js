export default {
  dashboard: {
    workplace: {
      project: 'Project Count',
      teamRank: 'Team rank',
      views: 'Views'
    }
  }
}
