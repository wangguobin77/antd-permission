export default {
  dashboard: {
    workplace: {
      project: '項目數',
      teamRank: '團隊排名',
      views: '訪問量'
    }
  }
}
