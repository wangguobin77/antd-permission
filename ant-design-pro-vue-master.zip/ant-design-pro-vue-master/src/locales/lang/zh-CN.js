export default {
  dashboard: {
    workplace: {
      project: '项目数',
      teamRank: '团队排名',
      views: '项目访问'
    }
  }
}
