export default {
  dashboard: {
    workplace: {
      project: '...',
      teamRank: '...',
      views: '...'
    }
  }
}
